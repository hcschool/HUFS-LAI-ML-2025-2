# 코드 실행 방법

## 노션 구현 파일 링크
- 노션 링크: https://www.notion.so/School-Notice-2bf4e2150bbe8092a843c4345a2ed1cd?source=copy_link

## 코드 실행 방법
- `model/`폴더 안에 assignment5에서 제출했던 `saved_model_v5`에서 `pytorch_model.bin`, `special_tokens_map.json`, `tokenizer_config.json`, `tokenizer.json`, `vocab.txt`를 다운받아야 합니다. (실제 사용은 CPU로 진행되기 때문)
- assignment5 모델 가중치 링크: https://drive.google.com/drive/folders/1P15TGD68mdmAd64ef7VWVsMK-DQjJq61?usp=sharing
- 파이썬 내장 라이브러리 설치:`pip install torch transformers requests beautifulsoup4 notion-client openai`
- 이후 `main.py`에서 터미널에 `python main.py`를 실행하면 크롤링부터 노션 등록 및 이메일 전송까지 자동으로 진행됩니다.

## 개인정보 관련해서 비워둔 부분
- 공개 레포라서 `notifier.py`에서 아래 부분은 비워 두었습니다. 이 부분은 모두 채워져야 코드 실행이 가능합니다.
```
# fmt: off
# ================= 사용자 설정 (여기를 채우세요) =================
EMAIL_ADDRESS =  # "본인의지메일@gmail.com"
EMAIL_PASSWORD =  # "여기에_앱비밀번호_16자리"
NOTION_TOKEN =   # "여기에_노션_시크릿토큰"
NOTION_DB_ID =  # "여기에_노션_데이터베이스_ID"
OPENAI_API_KEY =  # OPENAIAPI 키가 있다면 입력
# ===============================================================
# fmt: on
```
- gmail의 앱비밀번호 16자리 발급은 간단해서 이메일 발송까지 확인해 보고 싶으시면 번거로우시겠지만 교수님 계정으로 앱비밀번호를 생성해서 실행해 주시면 감사하겠습니다. 발급 방법은 아래에 있습니다.
- NOTION_TOKEN, NOTION_DB_ID, OPENAI_API_KEY는 따로 보내드리겠습니다. (노션의 경우 새로 페이지를 만드셔도 코드에 맞춰서 설정을 해야 해서 실행 결과는 링크로 열어보시는 것이 더 편할 것이라 생각합니다.)

### Gmail 앱비밀번호 16자리 (`EMAIL_PASSWORD`) 발급 방법
- Google 계정 관리 > 보안 탭으로 이동합니다.
- 'Google에 로그인' 섹션에서 2단계 인증을 켭니다.
- 검색창에 "앱 비밀번호" 검색 후 선택합니다.
- 앱 이름(예: NoticeBot)을 입력하고 "만들기"를 클릭합니다.
- 생성된 16자리 비밀번호를 복사하여 코드에 입력합니다.