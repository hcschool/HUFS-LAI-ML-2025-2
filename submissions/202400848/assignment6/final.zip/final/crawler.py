import requests
from bs4 import BeautifulSoup
import time
import random  # 랜덤 모듈 사용
import re
import urllib3
import json
import os

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 설정: 크롤링할 사이트 목록
SITES = [
    {
        "name": "공지(일반)",
        "url": "https://www.hufs.ac.kr/hufs/11281/subview.do",
        "base": "https://www.hufs.ac.kr",
    },
    {
        "name": "학사",
        "url": "https://www.hufs.ac.kr/hufs/11282/subview.do",
        "base": "https://www.hufs.ac.kr",
    },
    {
        "name": "장학",
        "url": "https://www.hufs.ac.kr/hufs/11283/subview.do",
        "base": "https://www.hufs.ac.kr",
    },
    {
        "name": "LAI_공지",
        "url": "https://langai.hufs.ac.kr/langai/m05_s01.do",
        "base": "https://langai.hufs.ac.kr",
    },
    {
        "name": "LAI_소식",
        "url": "https://langai.hufs.ac.kr/langai/m05_s02.do",
        "base": "https://langai.hufs.ac.kr",
    },
    {
        "name": "IEL_공지",
        "url": "https://iel.hufs.ac.kr/iel/m05_s01.do",
        "base": "https://iel.hufs.ac.kr",
    },
    {
        "name": "IEL_자유",
        "url": "https://iel.hufs.ac.kr/iel/m05_s03.do",
        "base": "https://iel.hufs.ac.kr",
    },
]

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

HISTORY_FILE = "history.json"


def load_history():
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def save_history(history):
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history[-500:], f, ensure_ascii=False, indent=2)


def clean_text(text):
    if not text:
        return ""
    return re.sub(r"\s+", " ", str(text)).strip()


def get_content(link):
    try:
        res = requests.get(link, headers=HEADERS, verify=False, timeout=10)
        res.encoding = "utf-8"
        soup = BeautifulSoup(res.text, "html.parser")
        content_tag = soup.select_one("div.view-con") or soup.select_one(".td-content")
        if content_tag:
            return clean_text(content_tag.text)
        return ""
    except:
        return ""


def crawl_latest():
    crawled_history = load_history()
    new_notices = []

    print(">>> 공지사항 크롤링 시작 (최신 페이지만 조회)...")

    for site in SITES:
        try:
            print(f"Checking {site['name']}...")
            res = requests.get(site["url"], headers=HEADERS, verify=False, timeout=10)
            res.encoding = "utf-8"
            soup = BeautifulSoup(res.text, "html.parser")

            rows = soup.select("table tbody tr")

            for row in rows:
                try:
                    title_tag = (
                        row.select_one(".td-subject span strong")
                        or row.select_one(".td-subject a")
                        or row.select_one(".td-subject")
                    )
                    if not title_tag:
                        continue
                    title = clean_text(title_tag.text)

                    link_tag = row.select_one("a")
                    if not link_tag:
                        continue
                    link = link_tag["href"]
                    if not link.startswith("http"):
                        link = site["base"] + link

                    if link in crawled_history:
                        continue

                    content = get_content(link)

                    date_tag = row.select_one(".td-date")
                    date = clean_text(date_tag.text) if date_tag else ""

                    print(f"  [New] {title}")

                    item = {
                        "category": site["name"],
                        "title": title,
                        "link": link,
                        "date": date,
                        "content": content,
                        "text": f"{title} {content}",
                    }
                    new_notices.append(item)
                    crawled_history.append(link)

                except Exception as e:
                    continue

            sleep_time = random.uniform(2, 4)
            time.sleep(sleep_time)

        except Exception as e:
            print(f"Error crawling {site['name']}: {e}")

    save_history(crawled_history)
    return new_notices
